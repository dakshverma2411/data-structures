#include<iostream>
using namespace std;

class SinglyLinkedListNode {
    public:
        int data;
        SinglyLinkedListNode *next;

        SinglyLinkedListNode(int node_data) {
            this->data = node_data;
            this->next = NULL;
        }
};

class SinglyLinkedList {
    public:
        SinglyLinkedListNode *head;
        SinglyLinkedListNode *tail;

        SinglyLinkedList() {
            this->head = NULL;
            this->tail = NULL;
        }

        void insert_node(int node_data) {
            /*code to insert new node at the end in linked list having node_data*/
		}
};

void print_singly_linked_list(SinglyLinkedListNode* node) {
    /*code to print linked list separated by single space*/
}

SinglyLinkedListNode* rearrange(SinglyLinkedListNode* head) {
	/*code to rearrange nodes*/	
}

int main() {
	SinglyLinkedList *LS = new SinglyLinkedList();
	/*code to read input and insert node in linked list*/
	LS = rearrange(LS->head);
	print_singly_linked_list(LS->head);
	return 0;
}